import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import promise from 'redux-promise';

import HomePage from './components/home_page';
import StorePage from './containers/store_page';
import OfferCategoryList from './containers/offer_category_list';
import reducers from './reducers';

const createStoreWithMiddleware = applyMiddleware(promise)(createStore);

ReactDOM.render(
  <Provider store={createStoreWithMiddleware(reducers)}>
    <BrowserRouter>
        <Switch>
            <Route exact path="/" component={HomePage}/>
            <Route path="/store/:store_name" component={StorePage}/>
            <Route path="/category/:category_name" component={OfferCategoryList}/>
        </Switch>
    </BrowserRouter>
  </Provider>
  , document.querySelector('.container'));
