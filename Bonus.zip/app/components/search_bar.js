import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

import SearchFilter from './search_filter';
import { filterStoreList } from '../actions';
import style from '../../style/search_bar.css';

class SearchBar extends Component {
    constructor(props){
        super(props);
        this.state = {
            term: '',
            categories: this.props,
            meta: {
                isCategoryShown: false
            }
        }

        this.onFormSubmit = this.onFormSubmit.bind(this);
        this.onInputChange = this.onInputChange.bind(this);
    }
    onInputChange(event) {
        this.setState({
            term: event.target.value.toLowerCase()
        });
        /* TODO: Remove if not needed */
        this.props.filterStoreList(this.state.term);
    }
    onFormSubmit(event) {
        event.preventDefault();
        this.props.filterStoreList(this.state.term);
    }

    toggleCategories(){
        this.setState({
            meta:{
                isCategoryShown: !this.state.meta.isCategoryShown
            }
        })
    }
    render() {
        return (
            <div className="srch-wrpr clearfix" className={`srch-wrpr clearfix ${this.state.meta.isCategoryShown?'srch-wrpr--full':''}`}>
                <div className="inpt--srch-grp clearfix">
                    <div className="inpt--srch-wrpr">
                        <form onSubmit={this.onFormSubmit}>
                            <input className="inpt inpt--srch" placeholder="Search all stores" value={this.state.term} onInput={this.onInputChange} />
                        </form>
                    </div>
                    <div className="srch-optn" onClick={()=>this.toggleCategories()}>
                        CATEGORIES
                    </div>
                </div>
                {
                    this.state.meta.isCategoryShown && <SearchFilter categories={this.props.categories} />
                }
            </div>
        );
    }
}

export default connect(null, { filterStoreList })(SearchBar);
