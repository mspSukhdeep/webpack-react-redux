import React from 'react';
import { Link } from 'react-router-dom';

export default function({categories}) {
    function getCategoryStyle(category) {
        return {
            color: category.color,
            background: `#fff url(${category.icon}) no-repeat center left 8px / 14px`,
            borderColor: category.color
        }
    }
    function renderFilterList(categories){
        if(categories.length>0){
            return (
                categories.map((category)=>{
                    return (
                            <Link to={`/category/${category.code}`} key={category.code} className="srch-fltr-item" style={getCategoryStyle(category)}>
                                {category.name}
                            </Link>
                    )
                })
            )
        } else{
            return(
                Array.from(Array(3)).map((value, index)=>{
                    return <div className="srch-fltr-item srch-fltr-item--empty" key={index}></div>
                })
            )
        }
    }
    return (
        <div className="srch-fltr-wrpr clearfix">
        {
            renderFilterList(categories)
        }
        </div>
    );
}
