import React from 'react';
import { Link } from 'react-router-dom';

import style from '../../../style/card.css';

export default ({store}) => {
    if(store.isEmpty){
        return (
            <div className="card card--ofr card--ofr--blank">
                <div className="card__img-wrpr"></div>
                <div className="btn card__btn"></div>
                <div className="card__sctn clearfix">
                    <div className="card__cb"></div>
                    <div className="card__cnt"></div>
                </div>
            </div>
            );
    }else{
        let url_path = '/store/'+store.store_name.toLowerCase();

        return (
            <div className="card card--ofr">
                <img className="card__img" src={store.image_url} />
                <Link to={url_path} className="btn card__btn">SHOP NOW</Link>
                <div className="card__sctn clearfix">
                    <div className="card__cb">{store.generic_text}</div>
                    <div className="card__cnt">{store.offers_count} Offers</div>
                </div>
            </div>
        );
    }
}
