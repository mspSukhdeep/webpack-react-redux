import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import style from '../../style/header.css';

export default class Header extends Component {
    render() {
        return (
            <header>
                <Link to="/" className="logo">
                    <img className="logo__img" src="https://assets.mspcdn.net/f_auto,c_scale,w_540/bonus_in/logo_white.png" alt="bonusapp" />
                </Link>
                <div className="usr_sctn">
                    <img className="usr_img" src="https://assets.mspcdn.net/msp-ui/icons/account-circle@2x.png" alt="User Image" />
                </div>
            </header>
        );
    }
}
