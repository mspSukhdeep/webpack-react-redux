import React, { Component } from 'react';
import { connect } from 'react-redux';
import { fetchStoreList } from '../actions';

import SearchBar from '../components/search_bar';
import StoreCard from '../components/cards/store_card';

class StoreList extends Component {
    componentDidMount() {
        if (this.props.stores.data.length==0){
            this.props.fetchStoreList();
        }
    }
    renderStoreList(){
        console.log(this.props);
        if(this.props.stores.data.length>0){
            return this.props.stores.data.reduce((filtered, store)=>{
                if(store.store_name.toLowerCase().indexOf(this.props.stores.meta.searchTerm) > -1){
                    filtered.push(<StoreCard key={store.store_name} store={store} />);
                }
                return filtered;
            }, [])
        } else{
            return <StoreCard store={{isEmpty: true}} />
        }
    }
    render() {
        return(
            <div>
                <SearchBar categories={this.props.stores.categories} />
                <div className="sctn card-list-wrpr">
                    {
                        this.renderStoreList()
                    }
                </div>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        stores: state.stores
    }
}
export default connect(mapStateToProps, { fetchStoreList })(StoreList);
