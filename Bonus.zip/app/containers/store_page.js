import React, { Component } from 'react';
import { connect } from 'react-redux';
import { fetchStoreDetails } from '../actions';

import Header from '../components/header';
import OfferCard from '../components/cards/offer_card';
import style from '../../style/store_page.css';

class StorePage extends Component {
    componentDidMount(){
        this.props.fetchStoreDetails(this.props.match.params.store_name);
    }
    render() {
        console.log(this.props.storeDetails);
        return (
            <div>
                <Header />
                <div className="sctn str-hdr">
                    <div className="str-hdr__inr">
                        <img className="str-hdr__img" src={this.props.storeDetails.meta.image_url} />
                        <div className="str-hdr__info clearfix">
                            <div className="str-hdr__cb">
                                {this.props.storeDetails.meta.generic_text}
                            </div>
                            <a target="_blank" href={this.props.storeDetails.meta.landing_url} className="btn str-hdr__btn">
                                SHOP NOW
                            </a>
                        </div>
                    </div>
                    <div className="str-hdr__view-cb">
                        View Cashback rates
                    </div>
                </div>
                {
                    this.props.storeDetails.categories.length>0 && (
                        <div className="str-fltr-wrpr">
                            <div className="str-fltr-wrpr__ttl">{this.props.match.params.store_name} Offers</div>
                            {
                                this.props.storeDetails.categories.map((category, currentIndex)=>{
                                    return (
                                        <div className="ctgry-fltr__item" key={currentIndex}>
                                            {category.name}
                                        </div>
                                    )
                                })
                            }
                        </div>
                    )
                }
                <div className="sctn card-list-wrpr">
                {
                    this.props.storeDetails.offers.map((offer, currentIndex)=>{
                        return <OfferCard key={currentIndex} offer={offer} />
                    })
                }
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        storeDetails: state.storeDetails
    }
}
export default connect(mapStateToProps, { fetchStoreDetails })(StorePage);
