import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import { connect } from 'react-redux';
import { fetchCategoryOfferList } from '../actions';

import Header from '../components/header';
import OfferCard from '../components/cards/offer_card';
import style from '../../style/offer_page.css';

class OfferCategoryList extends Component {
    constructor(props){
        super(props);
        this.state = {
            category_name: props.match.params.category_name
        }
    }
    componentDidMount(){
        this.props.fetchCategoryOfferList(this.state.category_name);
    }
    render() {
        return (
                <div>
                    <Header />
                    <Link to="/" className="sctn ctgry-hdr">
                        {this.state.category_name} Offers
                    </Link>
                    <div className="ctgry-fltr__wrpr">
                        {
                            this.props.categoryOffers.subcategories.map((category, currentIndex)=>{
                                return (
                                    <Link className="ctgry-fltr__item" key={currentIndex} to={`/subcategory/${category.code}`}>
                                        {category.name}
                                    </Link>
                                )
                            })
                        }
                    </div>
                    <div className="sctn card-list-wrpr">
                    {
                        this.props.categoryOffers.offers.map((offer, currentIndex)=>{
                            return <OfferCard key={currentIndex} offer={offer} />
                        })
                    }
                    </div>
                </div>
        )
    }

}

function mapStateToProps(state) {
    return {
        categoryOffers: state.categoryOffers
    }
}
export default connect(mapStateToProps, { fetchCategoryOfferList })(OfferCategoryList);
