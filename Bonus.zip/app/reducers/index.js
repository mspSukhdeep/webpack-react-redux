import { combineReducers } from 'redux';

import StoreListReducer from './store_list';
import OfferListReducer from './offer_list';
import CategoryOfferListReducer from './category_offer_list';
import StoreDetailReducer from './store_details';

const rootReducer = combineReducers({
  stores: StoreListReducer,
  offers: OfferListReducer,
  categoryOffers: CategoryOfferListReducer,
  storeDetails: StoreDetailReducer
});

export default rootReducer;
