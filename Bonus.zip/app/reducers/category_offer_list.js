import _ from 'lodash';

const initialState = {
    offers: [],
    subcategories: [],
    banks: []
};

export default function (state = initialState, action) {

    switch (action.type) {
        case "FETCH_CATEGORY_OFFER_LIST":
        return _.cloneDeep(action.payload.data);
        case "FILTER_CATEGORY_OFFER_LIST":
        return _.cloneDeep(action.payload.data);
        default:
            return state;
    }
}
