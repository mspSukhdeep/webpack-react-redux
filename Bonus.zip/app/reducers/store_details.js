const initialState = {
    meta: {},
    categories: [],
    subcategories: [],
    offers: []
};

export default function (state = initialState, action) {

    switch (action.type) {
        case "FETCH_STORE_DETAILS":
            return {
                meta: action.payload.data.store_info,
                categories: action.payload.data.categories?action.payload.data.categories:[],
                subcategories: action.payload.data.subcategories?action.payload.data.subcategories:[],
                offers: action.payload.data.offers
            }
        default:
            return state;
    }
}
