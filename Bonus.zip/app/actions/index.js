import axios from 'axios';

const API_URL = "https://sukhd.com/proxy/";
const RESOURCE_URL = "http://api.mysmartprice.com/v3/cashback/";

export function fetchStoreList() {
    // const url = `${API_URL}get_stores.php`;
    const request = axios.post(API_URL, {
            url:`${RESOURCE_URL}get_stores.php`
    });

    return {
        type: "FETCH_STORE_LIST",
        payload: request
    }
}

export function filterStoreList(term) {
    return {
        type: "FILTER_STORE_LIST",
        payload: term
    }
}

export function fetchOfferList() {
    const request = axios.post(API_URL, {
            url: `${RESOURCE_URL}get_offers.php`
    });

    return {
        type: "FETCH_OFFER_LIST",
        payload: request
    }
}

export function fetchCategoryOfferList(category) {
    const request = axios.post(API_URL, {
            url: `${RESOURCE_URL}get_offers.php?category=${category}`
    });

    return {
        type: "FETCH_CATEGORY_OFFER_LIST",
        payload: request
    }
}

export function fetchStoreDetails(store) {
    const request = axios.post(API_URL, {
            url: `${RESOURCE_URL}get_offers.php?store=${store}`
    });

    return {
        type: "FETCH_STORE_DETAILS",
        payload: request
    }
}
